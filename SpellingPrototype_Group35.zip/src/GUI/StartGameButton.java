package GUI;
import Main.GameStateManager;

/**
 * @author Tim Meyer-Smith
 */

@SuppressWarnings("serial")
public class StartGameButton extends ChangeStateButton {

    public StartGameButton() {
        super(GameStateManager.State.play);
        setup();
    }

    private void setup() {
        setText("START GAME");
    }

}
