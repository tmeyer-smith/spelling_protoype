package GUI;
import Main.GameStateManager;

/**
 * @author Tim Meyer-Smith
 */

@SuppressWarnings("serial")
public class NewGameButton extends ChangeStateButton {

    public NewGameButton() {
        super(GameStateManager.State.pregame);
        setup();
    }

    private void setup() {
        setText("PLAY");
    }

}
