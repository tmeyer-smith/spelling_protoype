package GUI;
import java.awt.Font;

import Main.GameStateManager;

/**
 * This is a button which is used to change the state of the game
 * back to the menu. It is in the corner of all states apart from
 * the menu and the video reward.
 * @author Tim Meyer-smith
 */

@SuppressWarnings("serial")
public class BackToMenuButton extends ChangeStateButton {

    public BackToMenuButton() {
    	super(GameStateManager.State.menu);
        setup();
    }

    private void setup() {
        setText("Return to Menu");
		setFont(new Font("Dialog", Font.BOLD, 25));
		setBounds(10, 11, 295, 50);
    }

}