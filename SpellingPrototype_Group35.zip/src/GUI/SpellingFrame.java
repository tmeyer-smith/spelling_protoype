package GUI;


import javax.swing.JFrame;

/**
 * @author Tim Meyer-Smith & Andrew Stewart
 */

@SuppressWarnings("serial")
public class SpellingFrame extends JFrame {
	
	
	/**
	 * Create the panel.
	 */
	public SpellingFrame() {
		setTitle("VOXSPELL");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(0, 0, 1200, 800);
		setResizable(false);
	}


}