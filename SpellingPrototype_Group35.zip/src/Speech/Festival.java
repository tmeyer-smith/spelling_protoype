package Speech;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

import Main.GameStateManager;

/**
 * @author Tim Meyer-Smith & Andrew Stewart
 */

public class Festival {
	
	
	public static void use(String message) {
		String voice = GameStateManager.getVoice();
        FestivalWorker worker = new FestivalWorker(message,voice);
        worker.execute();
    }
	
	public static String[] getVoices() {
		BufferedReader br = getVoicesReader();
		ArrayList<String> initVoices = extractVoices(br);
		String[] checkedVoices = checkVoicesUsable(initVoices);
		return checkedVoices;
		
	}

	private static BufferedReader getVoicesReader() {
		
		ProcessBuilder pb = new ProcessBuilder("bash","-c","echo \"(voice.list)\" | festival --interactive");
        try {
            Process p = pb.start();
            p.waitFor();
            return new BufferedReader(new InputStreamReader (p.getInputStream()));
        } catch (Exception e) {
            e.printStackTrace();
        }
		return null;
		
	}
	
	private static BufferedReader getVoiceCheckReader(String voice) {
		
		ProcessBuilder pb = new ProcessBuilder("bash","-c","echo \"(voice_" + voice + ")\" | festival --interactive");
        try {
            Process p = pb.start();
            p.waitFor();
            return new BufferedReader(new InputStreamReader (p.getInputStream()));
        } catch (Exception e) {
            e.printStackTrace();
        }
		return null;
		
	}
	
	private static ArrayList<String> extractVoices(BufferedReader br) {
		ArrayList<String> output = extractOutputFromBr(br);
		
		output = removeExtraLines(output);
		
		// Removes space at ( at start of first voice
		output.set(0, output.get(0).substring(1));
		
		// Removes space at start and ) at end of last voice
		output.set(output.size()-1, output.get(output.size()-1).substring(1, output.get(output.size()-1).length()-1));
		
		
		// Removes unwanted space at the start of each voice
		for (int i = 1; i<output.size()-1; i++) {
			output.set(i, output.get(i).substring(1));
		}
		
		return output;
	}
	
	
	private static String[] checkVoicesUsable(ArrayList<String> initVoices) {

  		for(int j=initVoices.size()-1;j>=0;j--) {
			if(!isVoiceUsable(initVoices.get(j))) {
				initVoices.remove(j);
			}
		}
		
		String[] voices = new String[initVoices.size()];
		
		// Convert ArrayList to String[]
		for (int i = 0; i<initVoices.size(); i++) {
			voices[i] = initVoices.get(i);
		}
		
		return voices;
	}
	
	private static boolean isVoiceUsable(String voice) {
		BufferedReader br = getVoiceCheckReader(voice);
		ArrayList<String> output = extractOutputFromBr(br);
		
		output = removeExtraLines(output);
		
		if (!output.isEmpty()) {
			String festivalReturnLine = output.get(0);


			if(!voice.equals(festivalReturnLine)) {
				return false;
			}
			else {
				return true;
			}
		}
		else {
			return false;
		}
	}

	private static ArrayList<String> extractOutputFromBr(BufferedReader br) {
		String line = "";
		ArrayList<String> output = new ArrayList<String>();
		try {
			while ((line = br.readLine()) != null) {
				output.add(line);
			}
		} 
		catch (IOException e) {
			e.printStackTrace();
		}
		
		return output;
	}
	
	private static ArrayList<String> removeExtraLines(ArrayList<String> output){

		// Finds where the intended output starts
		int firstVoiceIndex = 0;
		for(int j=0; j<output.size(); j++) {
			if(output.get(j).startsWith("festival>")) {
				firstVoiceIndex = j;
				break;
			}
		}

		// Removes unwanted lines at the start of output stream
		for (int i = 0; i<firstVoiceIndex; i++) {
			output.remove(0);
		}

		// Removes festival> at the start of intended output
		output.set(0, output.get(0).substring(10));

		// Finds index of last intended output line
		int lastVoiceIndex = output.size();
		for(int k=output.size()-1; k>=0; k--) {
			if(output.get(k).startsWith("festival>")) {
				lastVoiceIndex = k;
				break;
			}
		}

		// Removes "everything below the intended output
		for (int i = output.size()-1; i>=lastVoiceIndex; i--) {
			output.remove(i);
		}
		
		return output;
		
	}
	
	
	

}