package Speech;
import javax.swing.SwingWorker;

/**
 * @author Tim Meyer-Smith & Andrew Stewart
 */

public class FestivalWorker extends SwingWorker<Void, Void> {

    private String _message;
    private String _voice;

    public FestivalWorker(String message, String voice) {
        _message = message;
        _voice = voice;
    }

    public Void doInBackground() {
        sayMessage();
        return null;
    }

    private void sayMessage() {
        ProcessBuilder pb = new ProcessBuilder("festival","(voice_" + _voice + ")",
        		                               "(SayText \"" + _message + "\")" + "(quit)");
        try {
            Process p = pb.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}