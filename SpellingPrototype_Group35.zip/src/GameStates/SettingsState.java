package GameStates;
import java.awt.Font;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.JComboBox;
import javax.swing.JCheckBox;
import javax.swing.JLabel;

import Main.GameStateManager;
import Speech.Festival;
import WordProcessing.WordListsManager;

import javax.swing.DefaultComboBoxModel;

/**
 * @author Tim
 *
 */

@SuppressWarnings("serial")
public class SettingsState extends GameStatePanel {

	private JCheckBox chckbxResetStatistics;
	private JComboBox<String> voiceDropDown;
	private JLabel lblAnyUnsavedChanges;

	/**
	 * Create the panel.
	 */
	public SettingsState() {
		
		lblAnyUnsavedChanges = new JLabel("Any unsaved changes will be lost");
		lblAnyUnsavedChanges.setFocusable(false);
		lblAnyUnsavedChanges.setVisible(false);
		lblAnyUnsavedChanges.setForeground(Color.WHITE);
		lblAnyUnsavedChanges.setFont(new Font(_font, Font.BOLD, 15));
		lblAnyUnsavedChanges.setBounds(23, 68, 300, 48);
		add(lblAnyUnsavedChanges);
		
		final JButton btnSaveSettings = new JButton("SAVE SETTINGS");
		btnSaveSettings.setFocusable(false);
		btnSaveSettings.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				saveSettings();
				btnSaveSettings.setEnabled(false);
				lblAnyUnsavedChanges.setVisible(false);
				chckbxResetStatistics.setSelected(false);
			}
		}	
				);

		btnSaveSettings.setFont(new Font("Dialog", Font.BOLD, 20));
		btnSaveSettings.setBounds(480, 539, 240, 120);
		btnSaveSettings.setEnabled(false);
		add(btnSaveSettings);
		
		
		
		voiceDropDown = new JComboBox<String>();
		voiceDropDown.setFocusable(false);
		voiceDropDown.setModel(new DefaultComboBoxModel<String>(Festival.getVoices()));
		voiceDropDown.setBounds(398, 282, 158, 27);
		voiceDropDown.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				lblAnyUnsavedChanges.setVisible(true);
				btnSaveSettings.setEnabled(true);
			}
		}	
				);
		add(voiceDropDown);
		
		chckbxResetStatistics = new JCheckBox("Reset Statistics - This will delete all the statistics generated so far");
		chckbxResetStatistics.setFocusable(false);
		chckbxResetStatistics.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				lblAnyUnsavedChanges.setVisible(true);
				btnSaveSettings.setEnabled(true);
				chckbxResetStatistics.setSelected(true);
			}
		}	
				);
		chckbxResetStatistics.setFont(new Font(_font, Font.BOLD, 15));
		chckbxResetStatistics.setBackground(Color.BLACK);
		chckbxResetStatistics.setForeground(Color.WHITE);
		chckbxResetStatistics.setBounds(316, 378, 568, 41);
		chckbxResetStatistics.isSelected();
		add(chckbxResetStatistics);
		
		JLabel lblReadingVoice = new JLabel("Reading Voice - Choose which voice, you would like to be used in Play mode");
		lblReadingVoice.setFocusable(false);
		lblReadingVoice.setFont(new Font(_font, Font.BOLD, 15));
		lblReadingVoice.setForeground(Color.WHITE);
		lblReadingVoice.setLabelFor(voiceDropDown);
		lblReadingVoice.setBounds(289, 222, 622, 48);
		add(lblReadingVoice);
		
		JLabel lblResetStatistics = new JLabel("This includes your failed words and will make review mode unplayable");
		lblResetStatistics.setFocusable(false);
		lblResetStatistics.setForeground(Color.WHITE);
		lblResetStatistics.setFont(new Font("Dialog", Font.BOLD, 12));
		lblResetStatistics.setBounds(346, 410, 506, 34);
		add(lblResetStatistics);
		
		JButton btnTestVoice = new JButton("Test Voice");
		btnTestVoice.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String originalVoice = GameStateManager.getVoice();
				GameStateManager.changeVoice((String)voiceDropDown.getSelectedItem());
				Festival.use("This is what the voice sounds like");
				GameStateManager.changeVoice(originalVoice);
			}
		});
		btnTestVoice.setFocusable(false);
		btnTestVoice.setBounds(603, 281, 117, 27);
		add(btnTestVoice);
		
		
		
		super.setupBackground("SETTINGS");
		
		
	}
	
	
	private void saveSettings() {
		if(chckbxResetStatistics.isSelected()) {
			WordListsManager.clearStatistics();
		}
		
		if(!GameStateManager.getVoice().equals((String)voiceDropDown.getSelectedItem())) {
			GameStateManager.changeVoice((String)voiceDropDown.getSelectedItem());
		}
		
	}

}