package GameStates;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.SwingConstants;

import GUI.CorrectWordDisplayLabel;
import Main.GameStateManager;
import Main.InGameStorage;
import WordProcessing.WordListsManager;

/**
 * @author Tim Meyer-Smith & Andrew Stewart
 */

@SuppressWarnings("serial")
public class PostGameState extends GameStatePanel {

	private ArrayList<CorrectWordDisplayLabel> feedbackWordLabels;
	private int correctAnswers;

	public PostGameState(InGameStorage storage) {
		super.setupBackground("RESULTS");
		
		correctAnswers=0;

		feedbackWordLabels = storage.getFeedbackWordLabels();
		for (CorrectWordDisplayLabel lblWordsCorrect : feedbackWordLabels) {
			if(lblWordsCorrect.getBackground().equals(Color.green)) {
				correctAnswers++;
			}
			add(lblWordsCorrect);
		}

		ArrayList<JLabel> numberLabels = storage.getNumberLabels();
		for (JLabel lblWordsCorrect : numberLabels) {
			add(lblWordsCorrect);
		}

		int wordDisplayHeight = 40;

		int xBound = 271;
		int[] yBounds = {193, 244, 295, 346, 397, 448, 499, 550, 601, 652};

		for (int i=0; i<feedbackWordLabels.size(); i++) {
			CorrectWordDisplayLabel label = new CorrectWordDisplayLabel();
			label.setBounds(xBound, yBounds[i], 190, wordDisplayHeight);
			label.setBackground(Color.white);
			label.setVisible(true);
			label.setText(storage.getTestList()[i].toUpperCase());
			add(label);
		}


		JLabel lblCongratulations = new JLabel();
		lblCongratulations.setForeground(Color.WHITE);
		lblCongratulations.setFont(new Font("Dialog", Font.BOLD, 20));
		lblCongratulations.setBounds(540, 215, 530, 40);
		if(storage.getState().equals("play")) {
			if(correctAnswers>=9) { 
				lblCongratulations.setText("Congratulations You Completed Level " + GameStateManager.getLevel());
			}
			else {
				lblCongratulations.setText("Unfortunately You Did Not Pass Level " + GameStateManager.getLevel());
			}
		}
		else if (storage.getState().equals("review")) {
			if(correctAnswers==storage.getTestList().length) { 
				lblCongratulations.setText("Congratulations You Corrected Your Mistakes");
			}
			else {
				lblCongratulations.setText("You Still Have More Mistakes to Review");
			}
		}
		add(lblCongratulations);

		int level = Integer.parseInt(GameStateManager.getLevel());

		JLabel accuracyNum = new JLabel("");
		accuracyNum.setText(WordListsManager.getAccuracyForLevel(level)+"%");
		accuracyNum.setForeground(Color.WHITE);
		accuracyNum.setFont(new Font(_font, Font.BOLD, 20));
		accuracyNum.setBackground(Color.BLACK);
		accuracyNum.setBounds(916, 317, 124, 53);
		add(accuracyNum);

		JLabel correctStat = new JLabel("");
		correctStat.setText(WordListsManager.getNumWordsCorrectForLevel(level)+"/"+
				WordListsManager.getNumOfWordsInLevel(level));
		correctStat.setForeground(Color.WHITE);
		correctStat.setFont(new Font(_font, Font.BOLD, 20));
		correctStat.setBackground(Color.BLACK);
		correctStat.setBounds(916, 382, 124, 53);
		add(correctStat);


		JButton btnVideoReward = new JButton("Check Out Video Reward");
		btnVideoReward.setFocusable(false);
		btnVideoReward.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				GameStateManager.changeState(GameStateManager.State.videoReward);
			}
		});
		btnVideoReward.setBounds(671, 640, 268, 60);
		btnVideoReward.setFont(new Font(_font, Font.BOLD, 15));
		if(correctAnswers<9 || storage.getState().equals("review")) {
			btnVideoReward.setVisible(false);
		}
		add(btnVideoReward);

		
		JButton btnPlayNextLevel = new JButton("Play Next Level");
		btnPlayNextLevel.setFocusable(false);
		btnPlayNextLevel.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				int newLevel =Integer.parseInt(GameStateManager.getLevel()) + 1;
				GameStateManager.setLevel(newLevel+"");
				GameStateManager.changeState(GameStateManager.State.play);
			}
		});
		btnPlayNextLevel.setFont(new Font(_font, Font.BOLD, 15));
		btnPlayNextLevel.setBounds(671, 568, 268, 60);
		if(level>=11||correctAnswers<9 || storage.getState().equals("review")) {
			btnPlayNextLevel.setVisible(false);
		}
		add(btnPlayNextLevel);

		
		JButton btnTryLevelAgain = new JButton("Try Level Again");
		btnTryLevelAgain.setFocusable(false);
		btnTryLevelAgain.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				GameStateManager.changeState(GameStateManager.State.play);
			}
		});
		btnTryLevelAgain.setFont(new Font(_font, Font.BOLD, 15));
		btnTryLevelAgain.setBounds(671, 496, 268, 60);
		if(storage.getState().equals("review")) {
			btnTryLevelAgain.setVisible(false);
		}
		add(btnTryLevelAgain);
		
		JLabel lblWordsCorrect = new JLabel("Words Correct In This Level:");
		lblWordsCorrect.setHorizontalAlignment(SwingConstants.TRAILING);
		lblWordsCorrect.setForeground(Color.WHITE);
		lblWordsCorrect.setFont(new Font("Dialog", Font.BOLD, 20));
		lblWordsCorrect.setBackground(Color.BLACK);
		lblWordsCorrect.setBounds(581, 378, 323, 60);
		add(lblWordsCorrect);
		
		JLabel lblAccuracyForThis = new JLabel("Accuracy For This Level:");
		lblAccuracyForThis.setHorizontalAlignment(SwingConstants.TRAILING);
		lblAccuracyForThis.setForeground(Color.WHITE);
		lblAccuracyForThis.setFont(new Font("Dialog", Font.BOLD, 20));
		lblAccuracyForThis.setBackground(Color.BLACK);
		lblAccuracyForThis.setBounds(581, 310, 323, 60);
		add(lblAccuracyForThis);


	}


}
