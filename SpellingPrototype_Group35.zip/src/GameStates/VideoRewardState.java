package GameStates;
import javax.swing.JButton;

import com.sun.jna.Native;
import com.sun.jna.NativeLibrary;

import GUI.BackToMenuButton;
import uk.co.caprica.vlcj.binding.LibVlc;
import uk.co.caprica.vlcj.component.EmbeddedMediaPlayerComponent;
import uk.co.caprica.vlcj.player.embedded.EmbeddedMediaPlayer;
import uk.co.caprica.vlcj.runtime.RuntimeUtil;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * @author Tim Meyer-Smith & Andrew Stewart
 */

@SuppressWarnings("serial")
public class VideoRewardState extends GameStatePanel {

	private final EmbeddedMediaPlayerComponent mediaPlayerComponent;
	private final EmbeddedMediaPlayer video;
	private Boolean started;
	private JButton btnPausePlay;


	public VideoRewardState() {
		super.setupBackground("VIDEO");
		
		addVLCLibrary();
		
		mediaPlayerComponent = new EmbeddedMediaPlayerComponent();
		mediaPlayerComponent.setBounds(200, 220, 800, 400);
		add(mediaPlayerComponent);

		video = mediaPlayerComponent.getMediaPlayer();

		started = false;

		btnPausePlay = new JButton();
		btnPausePlay.setText("Play");
		btnPausePlay.setBounds(500, 650, 200, 100);
		btnPausePlay.setFont(new Font(_font, Font.BOLD, 15));
		btnPausePlay.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(!started) {
					startVideo();
					started = true;
					btnPausePlay.setText("Pause");
				}
				else {
					if (btnPausePlay.getText().equals("Pause")) {
						video.pause();
						btnPausePlay.setText("Play");
					} else {
						video.play();
						btnPausePlay.setText("Pause");
					}
				}
			}
		});
		add(btnPausePlay);
		
		
		BackToMenuButton btnExitVideoReward = new BackToMenuButton();
		btnExitVideoReward.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				video.stop();
			}
		});
		add(btnExitVideoReward);
	    
	}


	private void startVideo() {
		String filename = "big_buck_bunny_1_minute.avi";
		video.playMedia(filename);
	}

	private static void addVLCLibrary() {
        NativeLibrary.addSearchPath(RuntimeUtil.getLibVlcLibraryName(), "/usr/bin");
        //System.setProperty("jna.library.path", "/Applications/VLC.app/Contents/MacOS/lib");
        Native.loadLibrary("vlc", LibVlc.class);
    }

}