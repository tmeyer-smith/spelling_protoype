package GameStates;
import java.awt.Font;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;

import GUI.StartGameButton;
import GUI.StartReviewButton;
import Main.GameStateManager;
import WordProcessing.WordListsManager;

/**
 * @author Tim Meyer-Smith & Andrew Stewart
 */

@SuppressWarnings("serial")
public class PreGameState extends GameStatePanel {

	/**
	 * Create the panel.
	 */
	public PreGameState() {
		super.setupBackground(" VOXSPELL ");
	
		StartGameButton btnPlayGame = new StartGameButton();
		btnPlayGame.setFont(new Font(_font, Font.BOLD, 40));
		btnPlayGame.setBounds(425, 250, 350, 200);
		add(btnPlayGame);
		
		final StartReviewButton btnReview = new StartReviewButton();
		btnReview.setFont(new Font(_font, Font.BOLD, 30));
		btnReview.setBounds(425, 500, 350, 150);
		add(btnReview);
		
		if (!WordListsManager.failedWordsExist(GameStateManager.getLevel())) {
			btnReview.setEnabled(false);
		}
		
		JComboBox<String> comboBox = new JComboBox<String>();
		comboBox.setFont(new Font("Dialog", Font.BOLD, 20));
		comboBox.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				@SuppressWarnings("unchecked")
				JComboBox<String> dropDown = (JComboBox<String>)e.getSource();
				String chosenLevel = (String) dropDown.getSelectedItem();
				GameStateManager.setLevel(chosenLevel.substring(6));
				if (WordListsManager.failedWordsExist(chosenLevel.substring(6))) {
					btnReview.setEnabled(true);
				}
				else {
					btnReview.setEnabled(false);
				}
			}
		}
				);

		
		comboBox.setModel(new DefaultComboBoxModel<String>(new String[] {"Level 1", "Level 2", "Level 3", "Level 4",
				"Level 5", "Level 6", "Level 7", "Level 8", "Level 9", "Level 10", "Level 11"}));
		comboBox.setBounds(870, 250, 185, 59);
		comboBox.setSelectedIndex(Integer.parseInt(GameStateManager.getLevel())-1);
		add(comboBox);
		
	}

}