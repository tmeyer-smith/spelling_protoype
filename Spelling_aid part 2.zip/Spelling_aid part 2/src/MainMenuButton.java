import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.SwingUtilities;

@SuppressWarnings("serial")
public class MainMenuButton extends JButton {

	/**
	 * Create the panel.
	 */
	public MainMenuButton(int x, int y, int height, int width, String description) {
		this.setBounds(x,y,height,width);
		this.setText(description);
		this.setFont(new Font("Tahoma", Font.PLAIN, 16));
		this.setBackground(Color.WHITE);

		this.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JButton stateButton = (JButton) e.getSource();
				viewerFrame frame = (viewerFrame) SwingUtilities.getRoot(stateButton);
				frame.changeMode(stateButton.getText());
			}
		});
	}

}
