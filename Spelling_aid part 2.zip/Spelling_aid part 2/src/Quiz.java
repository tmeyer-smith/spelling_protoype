import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Quiz {
	private ArrayList<String> _wordList;
	private ArrayList<String> _quizList;

	Quiz(String mode) {
		String filename = null;
		if(mode.equals("SPELLING QUIZ")) {
			filename = "wordlist";
		}
		else if(mode.equals("REVIEW MISTAKES")) {
			filename = ".failWordlist";
		}
		Scanner sc;
		try {
			sc = new Scanner(new File(filename));
			_wordList = new ArrayList<String>();
			while (sc.hasNextLine()) {
				String nextLine = sc.nextLine();
				if(!nextLine.equals("")) {
					_wordList.add(nextLine);
				}	
			}
			sc.close();
		} catch (FileNotFoundException e) {
			////////////////////////////
			////NEED TO ADD THIS
			////////////////////////////
			e.printStackTrace();
		}
		
		_quizList = new ArrayList<String>();
		generateWords();
		
	}
	
	public String getNextWord() {
		String word =_quizList.get(0);
		_quizList.remove(0);
		return word;
	}
	
	public int getListSize() {
		return _quizList.size();
	}
	
	private void generateWords() {
		Random r = new Random();
		int amountOfWords = 3;
		if(_wordList.size()<3) {
			amountOfWords = _wordList.size();
		}
		for (int j =0;j<amountOfWords;j++) {
			int i = r.nextInt(_wordList.size());
			_quizList.add(_wordList.get(i));
			_wordList.remove(i);
		}
	}

}
