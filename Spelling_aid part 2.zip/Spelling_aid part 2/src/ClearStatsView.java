import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

@SuppressWarnings("serial")
public class ClearStatsView extends JPanel {
	
	JLabel lblClearedStats;

	/**
	 * Create the panel.
	 */
	public ClearStatsView() {
		setBackground(Color.BLACK);
		setLayout(null);
		
		
		JLabel lblTitle = new JLabel("CLEAR STATISTICS");
		lblTitle.setHorizontalTextPosition(SwingConstants.CENTER);
		lblTitle.setHorizontalAlignment(SwingConstants.CENTER);
		lblTitle.setFont(new Font("Tahoma", Font.BOLD, 22));
		lblTitle.setForeground(Color.WHITE);
		lblTitle.setBackground(Color.WHITE);
		lblTitle.setBounds(75, 0, 300, 80);
		add(lblTitle);
		
		JLabel lblAreYouSure = new JLabel("Are you sure you want to clear your statistics?");
		lblAreYouSure.setHorizontalAlignment(SwingConstants.CENTER);
		lblAreYouSure.setHorizontalTextPosition(SwingConstants.CENTER);
		lblAreYouSure.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblAreYouSure.setForeground(Color.WHITE);
		lblAreYouSure.setBackground(Color.WHITE);
		lblAreYouSure.setBounds(0, 109, 450, 30);
		add(lblAreYouSure);

		JButton btnMainMenu = new JButton("Main Menu");
		btnMainMenu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JButton returnToMenu = (JButton) e.getSource();
				viewerFrame frame = (viewerFrame) SwingUtilities.getRoot(returnToMenu);
				frame.changeMode("Main Menu");
			}
		});
		btnMainMenu.setBounds(160, 483, 125, 35);
		add(btnMainMenu);
		
		JButton btnClearStats = new JButton("Yes, Clear Stats");
		btnClearStats.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnClearStats.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				clearStats();
				JButton thisButton = (JButton) e.getSource();
				thisButton.setVisible(false);
				lblClearedStats.setVisible(true);
				repaint();
				revalidate();
			}
		});
		btnClearStats.setBounds(135, 177, 180, 70);
		add(btnClearStats);
		
		lblClearedStats = new JLabel("Statistics have been cleared!");
		lblClearedStats.setHorizontalTextPosition(SwingConstants.CENTER);
		lblClearedStats.setHorizontalAlignment(SwingConstants.CENTER);
		lblClearedStats.setForeground(Color.WHITE);
		lblClearedStats.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblClearedStats.setBackground(Color.WHITE);
		lblClearedStats.setBounds(0, 197, 450, 30);
		lblClearedStats.setVisible(false);
		add(lblClearedStats);
		
		
	}

	private void clearStats() {
		File statsFile = new File(".stats");
		File failureWordFile = new File(".failWordlist");
		statsFile.delete();
		failureWordFile.delete();
		try {
			statsFile.createNewFile();
			failureWordFile.createNewFile();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
