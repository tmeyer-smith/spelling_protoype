import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.ScrollPaneConstants;
import java.awt.Component;

@SuppressWarnings("serial")
public class ViewStatsView extends JPanel {
	private JTable table;

	/**
	 * Create the panel.
	 */
	public ViewStatsView() {
		setBackground(Color.BLACK);
		setLayout(null);
		
		
		JLabel lblTitle = new JLabel("VIEW STATISTICS");
		lblTitle.setHorizontalTextPosition(SwingConstants.CENTER);
		lblTitle.setHorizontalAlignment(SwingConstants.CENTER);
		lblTitle.setFont(new Font("Tahoma", Font.BOLD, 22));
		lblTitle.setForeground(Color.WHITE);
		lblTitle.setBackground(Color.WHITE);
		lblTitle.setBounds(75, 0, 300, 80);
		add(lblTitle);
		
		
		JButton btnMainMenu = new JButton("Main Menu");
		btnMainMenu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JButton returnToMenu = (JButton) e.getSource();
				viewerFrame frame = (viewerFrame) SwingUtilities.getRoot(returnToMenu);
				frame.changeMode("Main Menu");
			}
		});
		btnMainMenu.setBounds(160, 483, 125, 35);
		add(btnMainMenu);
		
		
		
		File stats = new File(".stats");
		ArrayList<String> failedWords = null; 
		try {
			failedWords = new ArrayList<>(Files.readAllLines(stats.toPath(), StandardCharsets.UTF_8));
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		String[][] data = new String[failedWords.size()/4][4];
		int count = 0;
		
		for(int i = 0; i<failedWords.size()/4; i++) {
			for(int j = 0; j<4; j++) {
				data[i][j]= failedWords.get(count);
				count++;
			}
		}
		
		String[] columnNames = {"Word","Mastered", "Faulted","Failed"};

		
		Arrays.sort(data, new Comparator<String[]>() {
			@Override
			public int compare(String[] row1, String[] row2) {
				String word1 = row1[0];
				String word2 = row2[0];
				return word1.compareTo(word2);
			}
		});

		table = new JTable(data,columnNames);
		table.setSelectionForeground(Color.WHITE);
		table.setBackground(Color.WHITE);
		table.setGridColor(Color.LIGHT_GRAY);
		table.setForeground(Color.BLACK);
		table.setRowHeight(20);
		table.setModel(new DefaultTableModel(data, columnNames));
		table.setFont(new Font("Tahoma", Font.PLAIN, 15));
		table.setBounds(10, 118, 430, 258);
		
		JScrollPane scrollPane = new JScrollPane(table);
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPane.setBounds(0, 90, 450, 350);
		table.setFillsViewportHeight(false);
		add(scrollPane);
	}
}
