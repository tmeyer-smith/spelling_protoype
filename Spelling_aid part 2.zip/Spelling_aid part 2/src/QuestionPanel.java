import java.awt.Color;
import java.awt.Font;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;

import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

@SuppressWarnings("serial")
public class QuestionPanel extends Panel {
	
	private JTextField _entryField;
	private JLabel _lblWrongMessage;
	private String _quizWord;
	private int _answered;
	
	
	QuestionPanel(String quizWord, int wordNumber, int x, int y, int width, int height) {
		_quizWord = quizWord;
		_answered = 0;
		
		setBackground(Color.BLACK);
		setBounds(x,y,width,height);
		setLayout(null);
		
		
		
		JLabel lblWord = new JLabel("WORD " +wordNumber + ":");
		lblWord.setBounds(50, 32, 87, 19);
		lblWord.setHorizontalAlignment(SwingConstants.CENTER);
		lblWord.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblWord.setForeground(Color.WHITE);
		add(lblWord);

		_entryField = new JTextField();
		_entryField.setBounds(147, 33, 230, 20);
		_entryField.setColumns(10);
		_entryField.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String answer = _entryField.getText(); 
				JTextField textField = (JTextField) e.getSource();
				QuestionPanel thisQuestion = (QuestionPanel) textField.getParent();
				QuizView thisQuizView = (QuizView) thisQuestion.getParent();
				setUpStats();
				if(!thisQuestion._quizWord.equals(answer)){
					if(_answered == 0) {
						_answered++;
						thisQuestion._lblWrongMessage.setVisible(true);
						
					}
					else if(_answered == 1) {
						_answered++;
						thisQuizView.printNextQuestion();
						addToStats(3);
						addToFailWordlist();
					}
				}
				else {
					if(_answered == 0) {
						_answered+=2;
						thisQuizView.printNextQuestion();
						addToStats(1);
						removeFromFailWordlist();
					}
					else if(_answered == 1) {
						_answered++;
						addToStats(2);
						removeFromFailWordlist();
					}
				};
				thisQuizView.repaint();
				thisQuizView.validate();
			}
		});
		add(_entryField);

		_lblWrongMessage = new JLabel("Incorrect, try once more!");
		_lblWrongMessage.setBounds(165, 64, 190, 20);
		_lblWrongMessage.setHorizontalAlignment(SwingConstants.CENTER);
		_lblWrongMessage.setForeground(Color.WHITE);
		_lblWrongMessage.setFont(new Font("Tahoma", Font.BOLD, 15));
		_lblWrongMessage.setVisible(false);
		add(_lblWrongMessage);
	}
	
	private void addToStats(int passRate) {
		try {
			File stats = new File(".stats");
			ArrayList<String> fileContent = new ArrayList<>(Files.readAllLines(stats.toPath(), StandardCharsets.UTF_8));
			
			for (int i = 0; i < fileContent.size(); i++) {
			    if (fileContent.get(i).equals(_quizWord)) {
			        Integer currentNumber = Integer.parseInt(fileContent.get(i+passRate));
			        currentNumber++;
			    	fileContent.set(i+passRate, currentNumber.toString());
			        break;
			    }
			}
			Files.write(stats.toPath(), fileContent, StandardCharsets.UTF_8);
	
		} catch (IOException e) {	
			e.printStackTrace();
		}
		

	}

	private void addToFailWordlist() {
		try {
			File fail = new File(".failWordlist");
			ArrayList<String> failedWords = new ArrayList<>(Files.readAllLines(fail.toPath(), StandardCharsets.UTF_8));
			if(!failedWords.contains(_quizWord)) {
				BufferedWriter output = new BufferedWriter(new FileWriter(".failWordlist", true));
				output.write(_quizWord);
				output.newLine();
				output.close();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	

	private void removeFromFailWordlist() {
		try {
			File fail = new File(".failWordlist");
			ArrayList<String> failedWords = new ArrayList<>(Files.readAllLines(fail.toPath(), StandardCharsets.UTF_8));
			if(failedWords.contains(_quizWord)) {
				failedWords.remove(_quizWord);
				Files.write(fail.toPath(), failedWords, StandardCharsets.UTF_8);
		    }
		
		} catch (IOException e) {
			e.printStackTrace();
		}
	}	

	private void setUpStats() {

		try {
			File stats = new File(".stats");
			ArrayList<String> statsFile = new ArrayList<>(Files.readAllLines(stats.toPath(), StandardCharsets.UTF_8));

			if(!statsFile.contains(_quizWord)) {
				BufferedWriter output = new BufferedWriter(new FileWriter(".stats", true));
				output.write(_quizWord);
				output.newLine();
				for(int i=0;i<3;i++){
					output.write("0");
					output.newLine();
				}
				output.close();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
}

