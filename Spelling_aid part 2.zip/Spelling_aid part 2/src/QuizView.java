import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;

import java.awt.Color;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;


@SuppressWarnings("serial")
public class QuizView extends JPanel {
	private ArrayList<QuestionPanel> _questions;
	private Quiz _currentGame;

	/**
	 * Create the panel.
	 */
	public QuizView(String mode) {
		
		_currentGame = new Quiz(mode);
		
		setBackground(Color.BLACK);
		setLayout(null);
		
		
		JLabel lblQuiz = new JLabel(mode);
		lblQuiz.setHorizontalTextPosition(SwingConstants.CENTER);
		lblQuiz.setHorizontalAlignment(SwingConstants.CENTER);
		lblQuiz.setFont(new Font("Tahoma", Font.BOLD, 22));
		lblQuiz.setForeground(Color.WHITE);
		lblQuiz.setBackground(Color.WHITE);
		lblQuiz.setBounds(75, 0, 300, 80);
		add(lblQuiz);
		
		JButton btnMainMenu = new JButton("Main Menu");
		btnMainMenu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JButton returnToMenu = (JButton) e.getSource();
				viewerFrame frame = (viewerFrame) SwingUtilities.getRoot(returnToMenu);
				frame.changeMode("Main Menu");
			}
		});
		btnMainMenu.setBounds(160, 483, 125, 35);
		add(btnMainMenu);
		
		

		if(_currentGame.getListSize() > 0) {
			_questions = new ArrayList<QuestionPanel>();
			QuestionPanel ques1 = new QuestionPanel(_currentGame.getNextWord(), 1, 0, 90, 450, 100);
			add(ques1);
		}
		else {
			JLabel lblNewLabel = new JLabel("Congratulations you currently have no mistakes to review");
			lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
			lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 16));
			lblNewLabel.setForeground(Color.WHITE);
			lblNewLabel.setBounds(0, 150, 450, 205);
			add(lblNewLabel);
		}
		if(_currentGame.getListSize() > 0) {
			QuestionPanel ques2 = new QuestionPanel(_currentGame.getNextWord(), 2, 0, 220, 450, 100);
			ques2.setVisible(false);
			add(ques2);
			_questions.add(ques2);
		}
		if(_currentGame.getListSize() > 0) {
			QuestionPanel ques3 = new QuestionPanel(_currentGame.getNextWord(), 3, 0, 350, 450, 100);
			ques3.setVisible(false);
			add(ques3);
			_questions.add(ques3);
		}
	}

	

	public void printNextQuestion() {
		if(_questions.size()>0) {
			_questions.get(0).setVisible(true);
			_questions.remove(0);
		}
	}
}
