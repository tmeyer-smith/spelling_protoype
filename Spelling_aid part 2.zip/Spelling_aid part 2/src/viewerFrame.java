import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;


import javax.swing.JLabel;
import java.awt.Color;
import java.awt.Font;
import java.io.File;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.SwingConstants;
import java.awt.Cursor;
import javax.swing.UIManager;



@SuppressWarnings("serial")
public class viewerFrame extends JFrame {
	
	private viewerFrame singleton = null;
	private JPanel contentPane;
	public enum Mode {MainMenu, NewQuiz, Review, ViewStats, ClearStats};
	private Mode _currentMode = Mode.MainMenu;


	public Mode getCurrentMode() {
		return _currentMode;
	}

	public void setCurrentMode(Mode newMode) {
		this._currentMode = newMode;
	}

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Throwable e) {
			e.printStackTrace();
		}
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					viewerFrame frame = new viewerFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	

	/**
	 * Create the frame.
	 */
	public viewerFrame() {
	
		if (this.singleton == null) {
			singleton = this;
		}
		loadMainMenu();	
		checkFiles();
	}
	
	private void checkFiles() {
		File statsFile = new File(".stats");
		File failureWordFile = new File(".failWordlist");
		try {
			statsFile.createNewFile();
			failureWordFile.createNewFile();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
		
	}
	
	public void loadMainMenu() {
		setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
		setResizable(false);
		setTitle("Spelling Aid");
		setBackground(Color.WHITE);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 560);
		contentPane = new JPanel();
		contentPane.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
		contentPane.setBackground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewQuiz = new MainMenuButton(135, 90, 180, 80, "New Quiz");
		contentPane.add(btnNewQuiz);
		
		JButton btnReviewMistakes = new MainMenuButton(135, 200, 180, 80,"Review Mistakes");
		contentPane.add(btnReviewMistakes);
		
		JButton btnViewStats = new MainMenuButton(135, 310, 180, 80, "View Statistics");
		contentPane.add(btnViewStats);
		
		JButton btnClearStats = new MainMenuButton(135, 420, 180, 80, "Clear Statistics");
		contentPane.add(btnClearStats);
		
		JLabel lblMainMenu = new JLabel("MAIN MENU");
		lblMainMenu.setHorizontalTextPosition(SwingConstants.CENTER);
		lblMainMenu.setHorizontalAlignment(SwingConstants.CENTER);
		lblMainMenu.setFont(new Font("Tahoma", Font.BOLD, 22));
		lblMainMenu.setForeground(Color.WHITE);
		lblMainMenu.setBackground(Color.WHITE);
		lblMainMenu.setBounds(145, 0, 160, 80);
		contentPane.add(lblMainMenu);
	}
	
	public void loadNewQuiz() {
		JPanel a = new QuizView("SPELLING QUIZ");
		contentPane.add(a);
		a.setBounds(0, 0, 450, 550);
		contentPane.repaint();
		contentPane.revalidate();
	}
	
	public void loadReview() {
		JPanel b = new QuizView("REVIEW MISTAKES");
		contentPane.add(b);
		b.setBounds(0, 0, 450, 550);
		contentPane.repaint();
		contentPane.revalidate();
	}
	
	public void loadViewStats() {
		JPanel c = new ViewStatsView();
		contentPane.add(c);
		c.setBounds(0, 0, 450, 550);
		contentPane.repaint();
		contentPane.revalidate();
	}
	
	public void loadClearStats() {
		JPanel d = new ClearStatsView();
		contentPane.add(d);
		d.setBounds(0, 0, 450, 550);
		contentPane.repaint();
		contentPane.revalidate();
	}
	
	public void changeMode(String mode) {

		contentPane.removeAll();
		
		switch(mode) {
		case "Main Menu": 
			setCurrentMode(Mode.MainMenu);
			loadMainMenu();
			break;
		case "New Quiz": 
			setCurrentMode(Mode.NewQuiz);
			loadNewQuiz();
			break;
		case "Review Mistakes": 
			setCurrentMode(Mode.Review);
			loadReview();
			break;
		case "View Statistics": 
			setCurrentMode(Mode.ViewStats);
			loadViewStats();
			break;
		case "Clear Statistics":
			setCurrentMode(Mode.ClearStats);
			loadClearStats();
			break;
		default: 
			break;
		}

		contentPane.repaint();
		contentPane.revalidate();
		
	}
}
